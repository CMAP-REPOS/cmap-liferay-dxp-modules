package contact.manager.app.application.util;

public class Utility {

	public static void touchPages(String rootPage) {
		
	}
}
