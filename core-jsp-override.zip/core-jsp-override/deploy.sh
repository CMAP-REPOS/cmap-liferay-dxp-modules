echo 'C3L7&Ib!QrO3'
scp -P 26 build/libs/com.liferay.blade.core.jsp.override-1.0.0.jar thirst@localhost:/webapps/qa-liferay-4p/liferay-dxp-digital-enterprise-7.0-sp4/deploy