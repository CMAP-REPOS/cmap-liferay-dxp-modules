package gov.illinois.cmap.custom.editor.base.configuration.constants;

/**
 * @author alejandroroiz
 */
public class CmapCustomEditorBaseConfigurationPortletKeys {

	public static final String CMAPCUSTOMEDITORBASECONFIGURATION =
		"gov_illinois_cmap_custom_editor_base_configuration_CmapCustomEditorBaseConfigurationPortlet";

}